"""
Aurora CS1

Description:
My own operating system
"""
import pygame
pygame.init()
welcome = print("Welcome to Aurora Color Spectrum 1")
copyright = print("Copyright Aurora Corp ©")
print()
print("Setup Your User")
name = input("What is your name: ")
username = input("What do you want your username to be: ")
password = input("What is going to be your password: ")
print("\n" * 100)
print("Sign in now")
guessuser = input("Username: ")
guesspass = input("Password: ")
print("\n" * 100)
if guessuser == username and guesspass == password:
    print("Welcome to Aurora CS1 ")
    while guessuser != username or guesspass != password:
        print("Sign in Error")
        print("Sign in now")
        guessuser = input("Username: ")
        guesspass = input("Password: ")
print("\n" * 100)
print("Welcome to Aurora " + name + "!")
startup_sfx = pygame.mixer.Sound("AcousticGuitarD.mp3")
startup_sfx.play()
year = input("Set the year ")
month = input("Type the name of the month ")
day = input("Type the day (please type the name of the day not the 20th for example) ")
print("\n" * 100)
print("Type dir for all Aurora commands executables and commands ")
print("if you need info on drives, type drive-info in cst")
typpo = input("A> ")
if typpo == "PRANX":
    print("Welcome to the world pranking network ")
elif typpo == "drive-info":
    print("Drive A is the main drive which stores the apps and the ms-dos command recievers so, if you try to type in a ms-dos command in drive B it won't work")
    print("drive B is where all the text based games are stored have fun!")
    print("drive C is where your security files are saved for example passwords and government information")
    print("drive D is children mode where children can use ms-dos freely without doing something wrong ")
    
elif typpo == "WRITE":
    print("Welcome to MS-Write")
    write =  input()
    print("\n" * 5)
    print(write)
elif typpo == "CALENDER":
    print("The month is " + month)
    print("The year is " + year)
    print("It is " + day)
elif typpo == "POTBELLY":
    print("You are a potbelly")
    print("Potty Potty Potbelly")
elif typpo == "EBAY":
    dirtchoice = input("Would You like to buy 10,000,000,000,000 dirt? y/n ")
    if dirtchoice == "y":
        print("you're broke now!")
    elif dirtchoice == "n":
        print("You're no fun😢")
    else:
        print("Can you repeat that?")
            
    
elif typpo == "BING":
    print("Welcome to bing")
    bingsearch = input("enter a url")
    if bingsearch:
        print("The Hardware is too old, you cannot run url's, sorry😢 ")
elif typpo == "drive-help":
    print("There are 4 drives, drive A, drive B, drive C and drive D, to go into them type for example 'B;' and that is how to use cd ")

elif typpo == "B;":
    print("\n" * 100)
    print("type dir for list of games on this drive")
    tuppo20 = input("B> ")
    if tuppo20 == "dir":
        print("GUESSWHO | .EXE")
        tuppo22 = input("B> ")
        if tuppo22 == "GUESSWHO":
            print("Welcome to ultimate guess who, you have one chance to guess which president the computer thought of")
            comguess = "George Washington"
            playguess = input("Enter a president: ")
            if playguess == comguess:
                print("Good Job!")
            else:
                print("bad luck😢")
                
        if tuppo20 == "GUESSWHO":
            print("Welcome to ultimate guess who, you have one chance to guess which president the computer thought of")
            comguess = "George Washington"
            playguess = input("Enter a president: ")
            if playguess == comguess:
                print("Good Job!")
            else:
                print("bad luck😢")
        

elif typpo == "C;":
    print("\n" * 100)
    print("Type dir to see all security files")
    potbellyreturns = input("C> ")
    if potbellyreturns == "dir":
        print("PASSWD | .txt")
        print("SOCIALSECURINFO | .txt")
        print("NAME | .TXT")
        print("BANKINGINFO | .bnk")
    potbelly4 = input("C> ")
    if potbelly4 == "PASSWD":
        print("Your password for this computer is " + password)
    elif potbelly4 == "SOCIALSECURINFO":
        print("Your social security info is 843493849839")
    elif potbelly4 == "NAME":
        print("Your name is " + name)
    elif potbelly4 == "BANKINGINFO":
        print("your banking locker number is 9084")
       
    


if typpo.lower() == "dir":
    print("COMMAND | .COM")
    print("PRANX | .EXE")
    print("WRITE | .EXE")
    print("POTBELLY | EXE")
    print("EBAY | .EXE")
    print("BING | .EXE")
    print("cd-help | .help")
    print("CALENDER | .EXE")
    typpo12 = input("A> ")
    if typpo12 == "COMMAND":
        print("Welcome to the DOS command line")
    elif typpo12 == "PRANX":
        print("Welcome to the world pranking network ")
    elif typpo12 == "CALENDER":
        print("The month is " + month)
        print("The year is " + year)
        print("It is " + day)
    
    elif typpo12 == "WRITE":
        print("Welcome to MS-Write")
        write =  input()
        print("\n" * 5)
        print(write)
    elif typpo12 == "POTBELLY":
        while True:
            print("You are a potbelly")
            print("Potty Potty Potbelly")
    elif typpo12 == "EBAY":
        dirtchoice = input("Would You like to buy 10,000,000,000,000 dirt? y/n ")
        if dirtchoice == "y":
            print("you're broke now!")
        elif dirtchoice == "n":
            print("You're no fun😢")
        else:
            print("Can you repeat that?")
        
    elif typpo12 == "BING":
        print("Welcome to bing")
        bingsearch = input("enter a url")
        if bingsearch:
            print("The Hardware is too old, you cannot run url's, sorry😢 ")

    elif typpo12 == "drive-help":
        print("There are 4 drives, drive A, drive B, drive C and drive D, to go into them type for example 'B;' and that is how ")
    elif typpo12 == "B;":
        print("\n" * 100)
        print("type dir for list of games on this drive")
        tuppo = input("B> ")
        if tuppo == "dir":
            print("GUESSWHO | .EXE")
            tuppo2 = input("B> ")
            if tuppo2 or tuppo == "GUESSWHO":
                print("Welcome to ultimate guess who, you have one chance to guess which president the computer thought of")
                comguess = "George Washington"
                playguess = input("Enter a president: ")
                if playguess == comguess:
                    print("Good Job!")
                else:
                    print("bad luck😢")

elif typpo == "C;":
    print("\n" * 100)
    print("Type dir to see all security files")
    potbellyreturns = input("C> ")
    if potbellyreturns == "dir":
        print("PASSWD | .txt")
        print("SOCIALSECURINFO | .txt")
        print("NAME | .TXT")
        print("BANKINGINFO | .bnk")
        potbelly4 = input("C> ")
        if potbelly4 == "PASSWD" or potbellyreturns == "PASSWD":
            print("Your password for this computer is " + password)
        elif potbelly4 == "SOCIALSECURINFO" or potbellyreturns == "SOCIALSECURINFO":
            print("Your social security info is 843493849839")
        elif potbelly4 == "NAME" or potbellyreturns == "NAME":
            print("Your name is " + name)
        elif potbelly4 == "BANKINGINFO" or potbellyreturns == "NAME":
            print("your banking locker number is 9084")
       


    

